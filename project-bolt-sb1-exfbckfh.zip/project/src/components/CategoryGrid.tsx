import React from 'react';
import { 
  Smartphone, 
  Car, 
  Home, 
  Shirt, 
  Gamepad2, 
  Wrench, 
  Baby, 
  BookOpen,
  Dumbbell,
  Briefcase,
  PawPrint,
  MoreHorizontal
} from 'lucide-react';
import { mockCategories } from '../utils/supabase';

const iconMap: { [key: string]: React.ReactNode } = {
  Smartphone: <Smartphone className="h-8 w-8" />,
  Car: <Car className="h-8 w-8" />,
  Home: <Home className="h-8 w-8" />,
  Shirt: <Shirt className="h-8 w-8" />,
  Gamepad2: <Gamepad2 className="h-8 w-8" />,
  Wrench: <Wrench className="h-8 w-8" />,
  Baby: <Baby className="h-8 w-8" />,
  BookOpen: <BookOpen className="h-8 w-8" />,
  Dumbbell: <Dumbbell className="h-8 w-8" />,
  Briefcase: <Briefcase className="h-8 w-8" />,
  PawPrint: <PawPrint className="h-8 w-8" />,
  MoreHorizontal: <MoreHorizontal className="h-8 w-8" />,
};

interface CategoryGridProps {
  onCategorySelect: (categoryId: string) => void;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ onCategorySelect }) => {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Browse Categories</h2>
          <p className="text-lg text-gray-600">Find exactly what you're looking for</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {mockCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategorySelect(category.id)}
              className="group flex flex-col items-center p-6 bg-white rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-200 transform hover:-translate-y-1"
            >
              <div className={`${category.color} p-4 rounded-full text-white mb-3 group-hover:scale-110 transition-transform duration-200`}>
                {iconMap[category.icon]}
              </div>
              <span className="text-sm font-medium text-gray-900 text-center leading-tight">
                {category.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryGrid;