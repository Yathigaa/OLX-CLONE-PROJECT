import React from 'react';
import { Star } from 'lucide-react';
import ProductCard from './ProductCard';
import { mockProducts } from '../utils/supabase';

interface FeaturedSectionProps {
  onProductClick: (productId: string) => void;
}

const FeaturedSection: React.FC<FeaturedSectionProps> = ({ onProductClick }) => {
  const featuredProducts = mockProducts.filter(product => product.is_featured);

  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center mb-8">
          <Star className="h-8 w-8 text-orange-500 mr-3" />
          <h2 className="text-3xl font-bold text-gray-900">Featured Listings</h2>
          <Star className="h-8 w-8 text-orange-500 ml-3" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onProductClick={onProductClick}
            />
          ))}
        </div>
        
        {featuredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No featured listings available at the moment.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FeaturedSection;