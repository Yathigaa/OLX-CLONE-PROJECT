import { createClient } from '@supabase/supabase-js';

// Use placeholder values when environment variables are not available
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

// Only create the client if we have real values, otherwise use null
export const supabase = (supabaseUrl !== 'https://placeholder.supabase.co' && supabaseAnonKey !== 'placeholder-key') 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Mock data for demonstration when Supabase is not connected
export const mockCategories = [
  { id: '1', name: 'Electronics', slug: 'electronics', icon: 'Smartphone', color: 'bg-blue-500' },
  { id: '2', name: 'Vehicles', slug: 'vehicles', icon: 'Car', color: 'bg-red-500' },
  { id: '3', name: 'Property', slug: 'property', icon: 'Home', color: 'bg-green-500' },
  { id: '4', name: 'Fashion', slug: 'fashion', icon: 'Shirt', color: 'bg-purple-500' },
  { id: '5', name: 'Hobbies', slug: 'hobbies', icon: 'Gamepad2', color: 'bg-yellow-500' },
  { id: '6', name: 'Home & Garden', slug: 'home-garden', icon: 'Wrench', color: 'bg-orange-500' },
  { id: '7', name: 'Kids & Baby', slug: 'kids-baby', icon: 'Baby', color: 'bg-pink-500' },
  { id: '8', name: 'Books', slug: 'books', icon: 'BookOpen', color: 'bg-indigo-500' },
];

export const mockProducts = [
  {
    id: '1',
    title: 'iPhone 14 Pro - Excellent Condition',
    description: 'Barely used iPhone 14 Pro in perfect condition. Comes with original box and charger.',
    price: 899,
    category_id: '1',
    category: mockCategories[0],
    user_id: '1',
    user: { id: '1', full_name: 'John Doe', phone: '+1234567890', location: 'New York, NY' },
    location: 'New York, NY',
    images: ['https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg'],
    condition: 'like-new' as const,
    is_featured: true,
    is_sold: false,
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
    views: 234
  },
  {
    id: '2',
    title: '2018 Honda Civic - Low Mileage',
    description: 'Well-maintained Honda Civic with only 45,000 miles. Great fuel economy and reliability.',
    price: 18500,
    category_id: '2',
    category: mockCategories[1],
    user_id: '2',
    user: { id: '2', full_name: 'Sarah Smith', phone: '+1234567891', location: 'Los Angeles, CA' },
    location: 'Los Angeles, CA',
    images: ['https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg'],
    condition: 'good' as const,
    is_featured: true,
    is_sold: false,
    created_at: '2024-01-14T15:30:00Z',
    updated_at: '2024-01-14T15:30:00Z',
    views: 156
  },
  {
    id: '3',
    title: 'Modern Sofa Set - Like New',
    description: 'Beautiful 3-piece sofa set in excellent condition. Moving sale - must go!',
    price: 1200,
    category_id: '6',
    category: mockCategories[5],
    user_id: '3',
    user: { id: '3', full_name: 'Mike Johnson', phone: '+1234567892', location: 'Chicago, IL' },
    location: 'Chicago, IL',
    images: ['https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg'],
    condition: 'like-new' as const,
    is_featured: false,
    is_sold: false,
    created_at: '2024-01-13T09:15:00Z',
    updated_at: '2024-01-13T09:15:00Z',
    views: 89
  },
  {
    id: '4',
    title: 'Gaming Laptop - High Performance',
    description: 'Perfect for gaming and work. RTX 3070, 16GB RAM, 1TB SSD. Barely used.',
    price: 1450,
    category_id: '1',
    category: mockCategories[0],
    user_id: '4',
    user: { id: '4', full_name: 'Emily Davis', phone: '+1234567893', location: 'Austin, TX' },
    location: 'Austin, TX',
    images: ['https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg'],
    condition: 'like-new' as const,
    is_featured: true,
    is_sold: false,
    created_at: '2024-01-12T14:20:00Z',
    updated_at: '2024-01-12T14:20:00Z',
    views: 312
  }
];