import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import CategoryGrid from './components/CategoryGrid';
import FeaturedSection from './components/FeaturedSection';
import ProductDetail from './components/ProductDetail';
import PostAdForm from './components/PostAdForm';
import SearchResults from './components/SearchResults';
import AuthModal from './components/AuthModal';
import MessagingModal from './components/MessagingModal';
import { SearchFilters, Product } from './types';
import { mockProducts } from './utils/supabase';

type AppView = 'home' | 'product' | 'post-ad' | 'search' | 'messaging';

function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({});
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isMessagingModalOpen, setIsMessagingModalOpen] = useState(false);
  const [selectedSellerId, setSelectedSellerId] = useState<string>('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setSearchFilters({ query });
    setCurrentView('search');
  };

  const handleCategorySelect = (categoryId: string) => {
    setSearchQuery('');
    setSearchFilters({ category: categoryId });
    setCurrentView('search');
  };

  const handleProductClick = (productId: string) => {
    setSelectedProductId(productId);
    setCurrentView('product');
  };

  const handlePostAd = () => {
    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    setCurrentView('post-ad');
  };

  const handleLogin = (email: string, password: string) => {
    // Mock login - in real app, this would authenticate with backend
    const mockUser = {
      id: 'user_1',
      email,
      full_name: 'John Doe',
      phone: '+1234567890',
      location: 'New York, NY'
    };
    
    setCurrentUser(mockUser);
    setIsLoggedIn(true);
    setIsAuthModalOpen(false);
  };

  const handleRegister = (userData: any) => {
    // Mock registration - in real app, this would create user in backend
    const newUser = {
      id: 'user_' + Date.now(),
      ...userData
    };
    
    setCurrentUser(newUser);
    setIsLoggedIn(true);
    setIsAuthModalOpen(false);
  };

  const handleContactSeller = (sellerId: string) => {
    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    
    const seller = mockProducts.find(p => p.user_id === sellerId)?.user;
    if (seller) {
      setSelectedSellerId(sellerId);
      setIsMessagingModalOpen(true);
    }
  };

  const handleAdSubmit = (adData: any) => {
    // Mock ad submission - in real app, this would save to backend
    console.log('New ad submitted:', adData);
    alert('Your ad has been posted successfully!');
    setCurrentView('home');
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedProductId('');
    setSearchQuery('');
    setSearchFilters({});
  };

  const selectedProduct = mockProducts.find(p => p.id === selectedProductId);
  const selectedSeller = mockProducts.find(p => p.user_id === selectedSellerId)?.user;

  return (
    <div className="min-h-screen bg-gray-50">
      {currentView === 'home' && (
        <>
          <Header 
            onSearch={handleSearch}
            onPostAd={handlePostAd}
            onLogin={() => setIsAuthModalOpen(true)}
          />
          <HeroSection onSearch={handleSearch} />
          <CategoryGrid onCategorySelect={handleCategorySelect} />
          <FeaturedSection onProductClick={handleProductClick} />
        </>
      )}

      {currentView === 'product' && (
        <ProductDetail
          productId={selectedProductId}
          onBack={handleBackToHome}
          onContactSeller={handleContactSeller}
        />
      )}

      {currentView === 'post-ad' && (
        <PostAdForm
          onBack={handleBackToHome}
          onSubmit={handleAdSubmit}
        />
      )}

      {currentView === 'search' && (
        <SearchResults
          query={searchQuery}
          filters={searchFilters}
          onBack={handleBackToHome}
          onProductClick={handleProductClick}
          onFiltersChange={setSearchFilters}
        />
      )}

      {/* Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      <MessagingModal
        isOpen={isMessagingModalOpen}
        onClose={() => setIsMessagingModalOpen(false)}
        sellerId={selectedSellerId}
        sellerName={selectedSeller?.full_name || ''}
        productTitle={selectedProduct?.title || ''}
      />
    </div>
  );
}

export default App;