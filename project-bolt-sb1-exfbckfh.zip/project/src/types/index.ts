export interface User {
  id: string;
  email: string;
  full_name: string;
  phone: string;
  location: string;
  avatar_url?: string;
  created_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  description?: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category_id: string;
  category?: Category;
  user_id: string;
  user?: User;
  location: string;
  images: string[];
  condition: 'new' | 'like-new' | 'good' | 'fair' | 'poor';
  is_featured: boolean;
  is_sold: boolean;
  created_at: string;
  updated_at: string;
  views: number;
}

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  product_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
}

export interface SearchFilters {
  query?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  location?: string;
  condition?: string;
  sortBy?: 'newest' | 'oldest' | 'price-asc' | 'price-desc';
}